package mainpackage;

public class RDAccount {
	double interestRate;
	double amount;
	int noOfMonths;
	double monthlyAmount;
	int age;
	
	double calculateInterest()
	{
		if(age<60)
		{
			 if(noOfMonths>=1 && noOfMonths<=6)
			 {
				 monthlyAmount=(amount*(double)(7.50/100));
				 return (monthlyAmount);
			 }
			 else if(noOfMonths>=7 && noOfMonths<=9)
			 {
				 monthlyAmount=(amount*(double)(7.75/100));
				 return (monthlyAmount);
			 }
			 else if(noOfMonths>=10 && noOfMonths<=12)
			 {
				 monthlyAmount=(amount*(double)(8.00/100));
				 return (monthlyAmount);
			 }
			 else if(noOfMonths>=13 && noOfMonths<=15)
			 {
				 monthlyAmount=(amount*(double)(8.25/100));
				 return (monthlyAmount);
			 }
			 else if(noOfMonths>=16 && noOfMonths<=18)
			 {
				 monthlyAmount=(amount*(double)(8.50/100));
				 return (monthlyAmount);
			 }
			 else if(noOfMonths>=19 && noOfMonths<=21)
			 {
				 monthlyAmount=(amount*(double)(8.75/100));
				 return (monthlyAmount);
			 }
		}
		
		else if(age>=60)
		{
			 if(noOfMonths>=1 && noOfMonths<=6)
			 {
				 monthlyAmount=(amount*(double)(8.00/100));
				 return (monthlyAmount);
			 }
			 else if(noOfMonths>=7 && noOfMonths<=9)
			 {
				 monthlyAmount=(amount*(double)(8.25/100));
				 return (monthlyAmount);
			 }
			 else if(noOfMonths>=10&& noOfMonths<=12)
			 {
				 monthlyAmount=(amount*(double)(8.50/100));
				 return (monthlyAmount);
			 }
			 else if(noOfMonths>=13 && noOfMonths<=15)
			 {
				 monthlyAmount=(amount*(double)(8.75/100));
				 return (monthlyAmount);
			 }
			 else if(noOfMonths>=16 && noOfMonths<=18)
			 {
				 monthlyAmount=(amount*(double)(9.00/100));
				 return (monthlyAmount);
			 }
			 else if(noOfMonths>=19 && noOfMonths<=21)
			 {
				 monthlyAmount=(amount*(double)(9.25/100));
				 return (monthlyAmount);
			 }
		}
		
		try
		 {
			 if(noOfMonths<0)
				 throw new Illegalvalue_exception();
			 
		 }
		 catch(Illegalvalue_exception e)
		 {
			 System.out.println("Exception   "+e);
			 
		 }
		return 0;
			 
		
	}

}
