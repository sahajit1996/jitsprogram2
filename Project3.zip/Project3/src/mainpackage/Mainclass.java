package mainpackage;
import java.util.*;

public class Mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		String s;
		Scanner sc=new Scanner(System.in);
		FDAccount obj1=new FDAccount();
		RDAccount obj2=new RDAccount();
		SBAccount obj3=new SBAccount();
		do
		{
			System.out.println("Main Menu");
			System.out.println("--------------");
			System.out.println("1.Interest Calculetor -SB");
			System.out.println("2.Interest Calculetor -FD");
			System.out.println("3.Interest Calculetor -RD");
			System.out.println("4.Exit");
			System.out.println("Enter your option  (1..4)");
			System.out.println("\n");
			i=sc.nextInt();
			switch(i)
			{
			case 1:
				System.out.println("Enter the Citizen Stutas ");
				obj3.stutas=sc.next();
				System.out.println("Enter the Avarage amount in your account");
				obj3.amount=sc.nextDouble();
				
				System.out.println("Interest Gained is : Rs."+obj3.calculateInterest());
				break;
			
			case 2:
				System.out.println("Enter the FD Amount ");
				obj1.amount=sc.nextDouble();
				System.out.println("Enter the Number of days ");
				obj1.noOfDays=sc.nextInt();
				System.out.println("Enter Your Age ");
				obj1.ageOfACHolder=sc.nextInt();
				System.out.println("Interest Gained is : Rs."+obj1.calculateInterest());
				break;
			case 3:
				System.out.println("Enter the RD Amount ");
				obj2.amount=sc.nextDouble();
				System.out.println("Enter the Number of Months ");
				obj2.noOfMonths=sc.nextInt();
				System.out.println("Enter Your Age ");
				obj2.age=sc.nextInt();
				System.out.println("Interest Gained is : Rs."+obj2.calculateInterest());
				break;
			case 4:
				System.exit(0);
				break;
				
				
			
			}
			
			
		}while(true);

	}

}
