package mainpackage;

public class FDAccount extends Account{
	double interestRate;
	double amount;
	int noOfDays;
	int ageOfACHolder;
	double yearlyamount;
	public double calculateInterest()
	 {
		
		 if(amount<10000000 )
		 {
			if(ageOfACHolder<60) 
			{
		 
			 if(noOfDays>=7 && noOfDays<=14)
			 {
				 yearlyamount=(amount*(double)(4.5/100));
				 return (yearlyamount);
			 }
			 else if(noOfDays>=15 && noOfDays<=29)
			 {
				 yearlyamount=(amount*(double)(4.75/100));
				 return (yearlyamount);
			 }
			 else if(noOfDays>=30 && noOfDays<45)
			 {
				 yearlyamount=(amount*(double)(5.50/100));
				 return (yearlyamount);
			 }
			 else if(noOfDays>=45 && noOfDays<=60)
			 {
				 yearlyamount=(amount*(double)(7.00/100));
				 return (yearlyamount);
			 }
			 else if(noOfDays>=61 && noOfDays<=184)
			 {
				 yearlyamount=(amount*(double)(7.50/100));
				 return (yearlyamount);
			 }
			 else if(noOfDays>=185 && noOfDays<=365)
			 {
				 yearlyamount=(amount*(double)(8.00/100));
				 return (yearlyamount);
			 }
		 }
			else if(ageOfACHolder>=60)
			{
				
				 if(noOfDays>=7 && noOfDays<=14)
				 {
					 yearlyamount=(amount*(double)(5.00/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=15 && noOfDays<=29)
				 {
					 yearlyamount=(amount*(double)(5.25/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=30 && noOfDays<45)
				 {
					 yearlyamount=(amount*(double)(6.00/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=45 && noOfDays<=60)
				 {
					 yearlyamount=(amount*(double)(7.50/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=61 && noOfDays<=184)
				 {
					 yearlyamount=(amount*(double)(8.00/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=185 && noOfDays<=365)
				 {
					 yearlyamount=(amount*(double)(8.50/100));
					 return (yearlyamount);
				 }
				
			}
	 }
		 else if(amount>=10000000)
		 {
			 if(ageOfACHolder<60)
			 {
				 if(noOfDays>=7 && noOfDays<=14)
				 {
					 yearlyamount=(amount*(double)(6.50/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=15 && noOfDays<=29)
				 {
					 yearlyamount=(amount*(double)(6.75/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=30 && noOfDays<45)
				 {
					 yearlyamount=(amount*(double)(6.75/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=45 && noOfDays<=60)
				 {
					 yearlyamount=(amount*(double)(8.00/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=61 && noOfDays<=184)
				 {
					 yearlyamount=(amount*(double)(8.50/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=185 && noOfDays<=365)
				 {
					 yearlyamount=(amount*(double)(10.00/100));
					 return (yearlyamount);
				 }
			 }
			 else if(ageOfACHolder>=60)
			 {
				 if(noOfDays>=7 && noOfDays<=14)
				 {
					 yearlyamount=(amount*(double)(6.50/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=15 && noOfDays<=29)
				 {
					 yearlyamount=(amount*(double)(6.75/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=30 && noOfDays<45)
				 {
					 yearlyamount=(amount*(double)(6.75/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=45 && noOfDays<=60)
				 {
					 yearlyamount=(amount*(double)(8.00/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=61 && noOfDays<=184)
				 {
					 yearlyamount=(amount*(double)(8.50/100));
					 return (yearlyamount);
				 }
				 else if(noOfDays>=185 && noOfDays<=365)
				 {
					 yearlyamount=(amount*(double)(10.00/100));
					 return (yearlyamount);
				 }
			 }
		 }
		 try
		 {
			 if(noOfDays<0)
				 throw new Illegalvalue_exception();
		 }
		 catch(Illegalvalue_exception e)
		 {
			 System.out.println("Exception   "+e);
		 }
		 return 0.00;
			 


}
}
