package mainpackage;

public class Illegalvalue_exception extends Exception{

	@Override
	public String toString() {
		return "Please Enter non-nagetive values";
	}
	

}
