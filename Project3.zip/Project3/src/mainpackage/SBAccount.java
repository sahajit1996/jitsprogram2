package mainpackage;

public class SBAccount extends Account{
	double interestRate;
	double amount;
	
	String stutas;
	 double calculateInterest()
	 {
		 if(stutas.equalsIgnoreCase("NORMAL"))
		 {
			 interestRate=(amount*(double)4.00/100);
			 return (interestRate);
		 }
		 else if(stutas.equalsIgnoreCase("NRI"))
		 {
			 interestRate=(amount*(double)6.00/100);
			 return (interestRate);
		 }
		 return 0.00;
		 
		 
	 }

}
