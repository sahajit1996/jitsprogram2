package MainPackage;

public abstract class Video {
	
	public String VideoName;
public boolean cheakout;
public	int rating;

	
	abstract String  getName();
	abstract void  doCheakout();
	abstract  void doReturn();
	abstract void  ReceiveRating(int rating);
	 abstract int getRating();
	 abstract  boolean getCheakout();
	 public Video(String name) {
			
			VideoName = name;
	
	}

}
