package MainPackage;
import java.io.*;
import java.util.*;

public class VideoLaucher extends Video implements VideoStore
{
	
	static  public VideoLaucher store[]=new VideoLaucher[2];
	static{
		 store[0]=new VideoLaucher("Matrix");
		 }
	 public VideoLaucher(String s)
		{
			super(s);
		}
	  
	 String s;
	 String r;
	 
	
			
	
	
public	void doReturn()
	{
	
	System.out.println("Enter the name of the Video that you want to return  "+r);

	
	}
	
public	void addVideo(String name)
	{
		System.out.println("Enter the video you want to add  "+store[0].getName());
		System.out.println("Video "+" "+name+" "+" added succesfully");
	}
	public  void doCheakout(String name)
	{
		s=name;
		if(store[0].getCheakout())
		System.out.println("Video"+s+"Cheaked out succesfully");
	}
	 public
	 String  getName()
	{
	
		 return VideoName;
		 
		
	}
	public void doReturn(String name)
	{
		r=name;
		if(store[0].getCheakout())
			super.cheakout=false;
		System.out.println("Video "+name+" returned Succesfully ");
	}
	 public void receiveRating(String name,int rating)
	{
		 store[0].ReceiveRating(rating);
		System.out.println(" Rating " +rating+" has been maped to this Video "+ name);
	}
	public void listinventory()
	{
		System.out.println("Video Name\t\t Cheakout Status\t\t Rating\t\t");
		System.out.println(VideoName+"\t\t\t\t"+cheakout+"\t\t\t"+rating+"\t\t");
		


		
		
	}
	public void doCheakout()
	{
		
		System.out.println("Enter the Video that you want to cheakout "+s);
	}
	
public 	void ReceiveRating(int rating)
	{
		super.rating=rating;
		System.out.println("Enter the vidio that you want t0 rate  "+store[0].getName());
		System.out.println("Enter the rating for this Video:  "+rating );
		return;
		
		
		
		
	}
	int getRating()
	{
		int rating=9;
	
	
		return (rating);
		
	}
	boolean getCheakout()
	{
		
		if(s.equalsIgnoreCase(store[0].getName()))
		{
			super.cheakout=true;
			return true;
		}
		if(r.equalsIgnoreCase(store[0].getName()))
		{
			super.cheakout=false;
			return false;
		}
		return true;
		
		
	}
	

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n;
		
		
		
		do {
			
		
			
	System.out.println("Main menu");
	System.out.println("================");
		System.out.println("1.addvideos");
		System.out.println("2.Cheakoutvideos");
		System.out.println("3.Return Videos");
		System.out.println("4.Recieve Rating");
		System.out.println("5.List Inventory");
		System.out.println("6.exit");
		System.out.println("Enter your choice 1..6");
		System.out.println("\t");
		n=sc.nextInt();
		switch(n)
		{
		case 1:
			store[0].addVideo(store[0].getName());
			
			break;
		case 4:
			
			store[0].receiveRating(store[0].getName(),store[0].getRating());


			
			break;
		case 2:
		{
			store[0].doCheakout(store[0].getName());
			store[0].doCheakout();
			
			break;
		}
		case 5:
		{
			store[0].listinventory();
			break;
		}
		case 3:
		{
			
			store[0].doReturn(store[0].getName());
			store[0].doReturn();
			break;
		}
		case 6:
		{
			System.out.println("Existing....!! Thanks for using The application");
			System.exit(0);
			break;
		}
		
		}
		}while(true);


		
		
		
	

	}

}
