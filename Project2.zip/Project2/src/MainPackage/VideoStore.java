package MainPackage;

public interface VideoStore {
	
	
	
			
	void addVideo(String name);
	void doCheakout(String name);
	void doReturn(String name);
	void receiveRating(String name,int rating);
	void listinventory();
	

}
