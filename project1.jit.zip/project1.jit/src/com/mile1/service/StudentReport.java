package com.mile1.service;
import com.mile1.exception.*;
import com.mile1.bean.*;


public class StudentReport {
	int[] studentmarks;
	int sum=0;
	public String findGrade(Student studentObject) 
	{
		studentmarks=studentObject.getMarks();
		
		for(int i=0;i<studentmarks.length;i++)
		{ 
	
			if(studentmarks[i]<35)
			{
				return "F";
			}
			else
			{
				sum+=studentmarks[i];				
				
			
				
				
			}
		}
		
		if(sum>250 && sum<=300)
			return "A";
		 if(sum>200 && sum<=250)
			return "B";
		 if(sum>150 && sum<=200)
			return "C";
		 if(sum<=150)
			return "D";
		
		 
		 return "";
			 
		
		
		
	}
	public String validate(Student studentObject)
	
	{
		try
		{
			if(studentObject==null)
				throw new NullStudentException();
			else
			{
				
				// System.out.println( findGrade(studentObject));
				
				if(studentObject.getName()==null)
					throw new NullNameException();
				else if(studentObject.getMarks()==null)
					throw new NullMarksArrayException();
				else 
				{
					System.out.println(studentObject.getName()+"  has "+findGrade(studentObject));
					
				}
			}
		}
		catch(NullStudentException e)
		{
			System.out.println(e);
		}
		catch(NullNameException e)
		{
			System.out.println(e);
		}
		catch(NullMarksArrayException e)
		{
			System.out.println(e);
		}
		
	
	return "";
		
	}
}
