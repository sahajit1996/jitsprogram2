package com.mile1.main;
import com.mile1.bean.*;
import com.mile1.exception.*;
import com.mile1.service.*;

public class ClassStudentMain {
	static Student data[]=new Student[4];
static
{
	data[0]=new Student("seker",new int[] {35,35,35});
	data[1]=new Student(null,new int[] {11,22,33});
	data[2]=null;
	data[3]=new Student("Manoj",null);
	
	
	
			
}
	public static void main(String[] args) {
			StudentService studentservice=new StudentService();
			StudentReport studentReport = new StudentReport (); 
			for(int i=0;i<data.length;i++)
			{
				studentReport.validate(data[i]);
			}
				System.out.println(studentservice.findNumberOfNullMarks(data));
				System.out.println(studentservice.findNumberOfNullNames(data));
				System.out.println(studentservice.findNumberOfNullObjects(data));
			
		
	}

}
