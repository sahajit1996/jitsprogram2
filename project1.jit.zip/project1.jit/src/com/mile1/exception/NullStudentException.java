package com.mile1.exception;

public class NullStudentException extends Exception{

	@Override
	public String toString() {
		return "NullStudentException occurred ";
	}

}
